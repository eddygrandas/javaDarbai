public enum Salis {
    LIETUVA,
    LATVIJA,
    ESTIJA
}
