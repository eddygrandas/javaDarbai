public class Reciever extends Asmuo{
    public Reciever(String vardas, int amzius) {
        super(vardas, amzius);
    }
}
