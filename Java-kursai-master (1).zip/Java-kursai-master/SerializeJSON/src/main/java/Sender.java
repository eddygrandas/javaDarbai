public class Sender extends Asmuo {
    public Sender(String vardas, int amzius) {
        super(vardas, amzius);
    }

    public Sender() {
    }
}
