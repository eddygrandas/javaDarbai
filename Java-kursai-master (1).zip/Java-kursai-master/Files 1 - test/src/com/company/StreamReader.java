package com.company;

public class StreamReader {
}
