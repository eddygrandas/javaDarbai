public class Soft {
    public static void main(String[] args) {
        System.out.printf("Labas");
    }
}
