class SoftTest extends groovy.util.GroovyTestCase {
    void testMain() {
    }
}
