public class Asmuo {
    private int id;
    private String name;
    private String lastName;
    private static int counter = 0;

    public Asmuo(String name, String lastName) {
        this.id=counter++;
        this.name = name;
        this.lastName = lastName;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getLastName() {
        return lastName;
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }
}
