public class SaskaitaNerastaException extends Throwable {
}
