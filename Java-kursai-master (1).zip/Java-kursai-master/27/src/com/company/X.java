package com.company;

public class X {
    public void metodasX(){
        System.out.println("Iskviestas metodas X");
    }
}
