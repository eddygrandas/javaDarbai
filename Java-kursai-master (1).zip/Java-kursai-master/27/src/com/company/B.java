package com.company;

public class B extends X {
}
