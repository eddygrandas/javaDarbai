package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Korta korta = new Korta(1,1);
        System.out.println();

    }
}
