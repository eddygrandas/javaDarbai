package com.company;

class Keyboard extends Device {
    Keyboard(boolean b) {
        super(b);
    }
}
