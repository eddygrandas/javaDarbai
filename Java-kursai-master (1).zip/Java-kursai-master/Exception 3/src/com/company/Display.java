package com.company;

class Display extends Device {
    Display(boolean b) {
        super(b);
    }
}
