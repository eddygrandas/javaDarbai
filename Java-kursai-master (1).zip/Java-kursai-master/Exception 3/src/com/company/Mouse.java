package com.company;

class Mouse extends Device {
    Mouse(boolean b) {
        super(b);
    }
}
