package com.company;

class DeviceIsOffException extends Exception {
}
