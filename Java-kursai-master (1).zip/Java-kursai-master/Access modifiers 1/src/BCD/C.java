package BCD;

public class C extends B{
B b = new B();
    void a(){
    System.out.println(b.w());
}
}
