package BCD;

public class D {
    B b = new B();
    public String x = b.getX();
    public String y = b.y();

}
