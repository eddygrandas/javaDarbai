package BCD;

public class B {

    private String x(){
        return "Method X";
    }

    String y(){
        return "Method Y";
    }

    protected String w(){
        return "Method W";
    }

    public String z(){
        return "Method Z";
    }

    public String getX(){
        return this.x();
    }
}
