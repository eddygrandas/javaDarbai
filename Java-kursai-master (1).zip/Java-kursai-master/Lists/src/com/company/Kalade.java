package com.company;

public class Kalade {
}
