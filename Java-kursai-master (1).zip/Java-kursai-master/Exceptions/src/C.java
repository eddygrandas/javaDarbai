public class C {
    public void methodC() {
        String a = null;
        System.out.println(a.indexOf(a));
    }
}
