public class B {
    public void callC(){
        C c = new C();
        c.methodC();
    }
}
