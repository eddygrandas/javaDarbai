package Matematika;

public class Main {

    public static void main(String[] args) {
        Math sum = new Math();
        sum.addTwoValue(12, 6);
        sum.showSumOfTwoValues();
    }
}
