package com.company;

public enum Gender {
    FEMALE,
    MALE
}
