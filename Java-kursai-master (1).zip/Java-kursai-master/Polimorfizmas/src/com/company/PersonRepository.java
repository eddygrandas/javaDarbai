package com.company;

import java.util.ArrayList;
import java.util.List;

public class PersonRepository {
    List<Person> personsList = new ArrayList<>();
    static Person getPersons(){

        return null;
    }
}
