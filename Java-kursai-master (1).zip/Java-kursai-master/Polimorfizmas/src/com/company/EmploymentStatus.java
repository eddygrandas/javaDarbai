package com.company;

public enum EmploymentStatus {
    EMPLOYED,
    UNEMPLOYED
}
