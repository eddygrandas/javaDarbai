package ml.penkisimtai.crm.model;

public enum CustomerTypeEnum {
    SIMPLE,
    LOYAL;

//    SIMPLE("SIMPLE"),
//    LOYAL("LOYAL");
//
//    private final String name;
//
//    CustomerTypeEnum(String name){
//        this.name = name;
//    }
//
//    public String getName(){
//        return name;
//    }

}
