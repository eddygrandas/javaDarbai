package com.company;

public enum DnsProvider {
    GOOGLE,
    CLOUDFLARE
}
