package com.company;

public class Egle extends Spygliuotis {
    public Egle() {
        super.setLapas(getClass().getSimpleName()+" turi spyglius.");
    }
}
