package com.company;

public class Pusis extends Spygliuotis {
    public Pusis() {
        super.setLapas(getClass().getSimpleName()+" turi spyglius.");
    }
}
