package com.company;

public class Berzas extends Lapuotis {
    public Berzas() {
        super.setLapas(getClass().getSimpleName()+" turi lapus.");
    }
}
