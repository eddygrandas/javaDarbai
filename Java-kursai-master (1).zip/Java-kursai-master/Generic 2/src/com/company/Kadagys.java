package com.company;

public class Kadagys extends Spygliuotis {
    public Kadagys() {
        super.setLapas(getClass().getSimpleName()+" turi spyglius.");
    }
}
