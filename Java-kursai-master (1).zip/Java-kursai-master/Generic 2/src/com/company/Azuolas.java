package com.company;

public class Azuolas extends Lapuotis {
    public Azuolas() {
        super.setLapas(getClass().getSimpleName()+" turi lapus.");
    }
}
