package com.company;

public interface Medis {
    void turi();
}
