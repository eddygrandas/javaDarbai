package jorge.rv.quizzz.service.accesscontrol;

import org.springframework.stereotype.Service;

import jorge.rv.quizzz.model.Answer;

@Service
public class AccessControlServiceAnswer extends AccessControlServiceUserOwned<Answer> {

}
