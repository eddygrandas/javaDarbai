package jorge.rv.quizzz.service.usermanagement.utils;

public interface TokenGenerator {

	String generateRandomToken();

}