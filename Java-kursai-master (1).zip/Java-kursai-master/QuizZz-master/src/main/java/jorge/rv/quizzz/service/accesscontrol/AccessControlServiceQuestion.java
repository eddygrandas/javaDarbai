package jorge.rv.quizzz.service.accesscontrol;

import org.springframework.stereotype.Service;

import jorge.rv.quizzz.model.Question;

@Service
public class AccessControlServiceQuestion extends AccessControlServiceUserOwned<Question> {

}
