package com.company;

public class Spygliuotis extends Medis {
    public Spygliuotis() {
        super.setLapas("Spygliuotis");
        //System.out.println("Spygliuotis");
    }
}
