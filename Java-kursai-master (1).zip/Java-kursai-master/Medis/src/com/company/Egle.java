package com.company;

public class Egle extends Spygliuotis {
    public Egle() {
        super.auginti();
        super.setRusis("Egle");
    }
}
