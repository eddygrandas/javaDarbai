package com.company;

public class Uosis extends Lapuotis {
    public Uosis() {
        super.auginti();
        super.setRusis("Uosis");
    }
}
