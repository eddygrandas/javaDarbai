package com.company;

public class Berzas extends Lapuotis {
    public Berzas() {
        super.auginti();
        super.setRusis("Berzas");;
    }

}
