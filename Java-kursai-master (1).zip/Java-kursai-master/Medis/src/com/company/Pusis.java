package com.company;

public class Pusis extends Spygliuotis {
    public Pusis() {
        super.auginti();
        super.setRusis("Pusis");
    }
}
